import random
import json
import os

from pico2d import*

import game_framework
import game_shop

location = None
menu = None
monster = None

click_upgrade = 10

MAPSIZE = 1024

class Monster:
    image = None

    STAND, ATTACK = 1, 2
    frame_count, count = 0, 0
    drop_coin = 0
    click = 0
    hp = 0

    def handle_stand(self):
        if self.click == 1:
            self.frame = 1
            self.frame_count = 0
            self.hp += click_upgrade
            self.state = self.ATTACK
        if self.hp == 210:
            self.frame_count = 210
            #self.hp = 0 #체력 되돌리기(임시)

    def handle_attack(self):
        if self.click == 0:
            self.state = self.STAND

    handle_state = {
        STAND: handle_stand,
        ATTACK: handle_attack
    }

    def __init__(self):
        self.image = load_image('monsters1.png')
        self.state = self.STAND
        self.frame = 1
        self.frame_count = 0

    def update(self):
        if self.state == self.STAND:
            if self.frame_count < 100:
                self.frame = 1
            elif self.frame_count < 200:
                self.frame = 2
            elif self.frame_count == 200:
                self.frame_count = 0
            elif self.frame_count == 210:
                self.frame = 0
        self.frame_count += 1
        self.handle_state[self.state](self)

    def draw(self):
        self.image.clip_draw(self.frame * 330, MAPSIZE - self.state * 340, 300, 300, 240, 440)

def handle_events():
    global x, y
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_MOUSEBUTTONUP and event.button == SDL_BUTTON_LEFT:
            if (55 < event.x and event.x < 265) and (680 < event.y and event.y < 750):
                game_framework.change_state(game_shop)
            else: monster.click = 0
        elif event.type == SDL_MOUSEBUTTONDOWN and event.button == SDL_BUTTON_LEFT:
            monster.click = 1

def enter():
    global location, menu, monster
    location = load_image('location_1.jpg')
    menu = load_image('main6.png')
    monster = Monster()

def exit():
    global location, menu, monster
    del(location)
    del(menu)
    del(monster)

def draw():
    clear_canvas()
    location.draw(240, 400) #배경
    menu.clip_draw(565, MAPSIZE - 514, 90, 75, 240, 700) #현재 맵
    menu.clip_draw(940, MAPSIZE - 910, 90, 75, 330, 700) #다음 맵
    menu.clip_draw(755, MAPSIZE - 620, 35, 60, 240, 680) #현재 맵 표시 화살표
    menu.clip_draw(0, MAPSIZE - 550, 340, 60, 240, 775) #돈 액수 표현
    menu.clip_draw(342, MAPSIZE - 260, 40, 35, 140, 775) #돈 모양
    menu.clip_draw(342, MAPSIZE - 260, 40, 35, 120, 775) #돈 모양
    menu.clip_draw(455, MAPSIZE - 1024, 485, 190, 240, 80) #공격력 상태표시
    menu.clip_draw(760, MAPSIZE - 835, 210, 60, 160, 80) #동료 영웅 상점
    menu.clip_draw(130, MAPSIZE - 240, 210, 20, 240, 250) #몬스터 체력감소
    menu.clip_draw(130, MAPSIZE - 215, 210 - monster.hp, 20, 240 - monster.hp / 2, 250) #몬스터 체력표시
    monster.draw()
    update_canvas()

def update():
    monster.update()

def pause():
    pass

def resume():
    pass