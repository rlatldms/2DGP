import random
import json
import os

from pico2d import*

import game_framework
import game_main

logo = None
menu = None
shop = None
shop2 = None

click_upgrade = 10

MAPSIZE = 1024
MAPSIZE2 = 256

def handle_events():
    global click_upgrade
    global x, y
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        # elif event.type == SDL_MOUSEBUTTONUP and event.button == SDL_BUTTON_LEFT:
        #     click_upgrade = 0
        elif event.type == SDL_MOUSEBUTTONDOWN and event.button == SDL_BUTTON_LEFT:
            if (432 < event.x and event.x < 468) and (13 < event.y and event.y < 37):
                game_framework.change_state(game_main)
            elif (8 < event.x and event.x < 472) and (123 < event.y and event.y < 217):
                click_upgrade += 10

def enter():
    global logo, menu, shop, shop2
    logo = load_image('CW_load_screen.jpg')
    menu = load_image('main6.png')
    shop = load_image('shop.png')
    shop2 = load_image('shop4.png')

def exit():
    global logo, menu, shop, shop2
    del(logo)
    del(menu)
    del(shop)
    del(shop2)

def draw():
    clear_canvas()
    logo.draw(240, 400)
    menu.clip_draw(0, MAPSIZE - 550, 340, 60, 240, 775) #돈 액수 표현
    menu.clip_draw(342, MAPSIZE - 260, 40, 35, 140, 775) #돈 모양
    menu.clip_draw(342, MAPSIZE - 260, 40, 35, 120, 775) #돈 모양
    shop.clip_draw(0, MAPSIZE2 - 90, 162, 66, 240, 710)
    shop.clip_draw(500, MAPSIZE2 - 90, 65, 40, 240, 710) #캐릭터 강화
    shop.clip_draw(0, MAPSIZE2 - 250, 465, 95, 240, 630) #캐릭터 강화창
    shop.clip_draw(470, MAPSIZE2 - 250, 480, 40, 240, 670)
    shop.clip_draw(395, MAPSIZE2 - 155, 75, 75, 50, 630)
    shop2.clip_draw(605, MAPSIZE - 370, 37, 35, 450, 775)  #나가기
    update_canvas()

def update():
    pass

def pause():
    pass

def resume():
    pass