from pico2d import*

import game_framework
import game_title

location = None
menu = None

def handle_events():
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()

def enter():
    global location, menu
    location = load_image('location_1.jpg')
    menu = load_image('main6.png')

def exit():
    global location, menu
    del(location)
    del(menu)

def draw():
    clear_canvas()
    location.draw(240, 400) #배경
    menu.clip_draw(565, 1024 - 514, 90, 75, 240, 700) #현재 맵
    menu.clip_draw(940, 1024 - 910, 90, 75, 330, 700) #다음 맵
    menu.clip_draw(755, 1024 - 620, 35, 60, 240, 680) #현재 맵 표시 화살표
    menu.clip_draw(0, 1024 - 550, 340, 60, 240, 775) #돈 액수 표현
    menu.clip_draw(342, 1024 - 260, 40, 35, 140, 775) #돈 모양
    menu.clip_draw(342, 1024 - 260, 40, 35, 120, 775) #돈 모양
    menu.clip_draw(455, 1024 - 1024, 485, 190, 240, 80) #공격력 상태표시
    menu.clip_draw(760, 1024 - 835, 210, 60, 160, 80) #동료 영웅 상점
    menu.clip_draw(130, 1024 - 215, 210, 20, 240, 250) #몬스터 체력표시
    update_canvas()

def update():
    pass

def pause():
    pass

def resume():
    pass