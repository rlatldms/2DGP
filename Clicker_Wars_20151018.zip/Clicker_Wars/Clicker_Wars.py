import game_framework
import game_title

game_framework.run(game_title)