from pico2d import*

import game_framework
import game_shop
import random

image_size = 1024
false = 0
true = 1

class Location:
    image = None

    def __init__(self):
        self.image = load_image('location/location_1.jpg')

    def draw(self):
        self.image.draw(240, 400)

class Monsters:
    image = None

    MONSTERS_STAND, MONSTERS_ATTACK = 1, 2

    def __init__(self):
        if Monsters.image == None:
            Monsters.iamge = load_image('monsters/monsters1.png')
        self.hp = 0
        self.coin = 0
        self.time = 20
        self.damage = 10
        self.click = false
        self.upgrade_coin = 100

        self.frame = 1
        self.frame_delay = 0
        self.state = self.MONSTERS_STAND

    def draw(self):
        self.iamge.clip_draw(330 * self.frame, image_size - 340 * self.state, 300, 300, 240, 440)

    def update(self):
        if self.state == self.MONSTERS_STAND:
            if self.frame_delay < 200:
                self.frame = 1
            elif self.frame_delay < 400:
                self.frame = 2
            else: self.frame_delay = 0
            self.frame_delay += 1
        self.time -= 0.003
        self.handle_state[self.state](self)

    def handle_stand(self):
        if self.hp >= 210:
            self.frame = 0
        elif self.click == true:
            self.hp += self.damage
            self.state = self.MONSTERS_ATTACK

    def handle_attack(self):
        self.frame = 1
        if self.click == false:
            self.state = self.MONSTERS_STAND

    handle_state = {
        MONSTERS_STAND:handle_stand,
        MONSTERS_ATTACK:handle_attack
    }

class Menu:
    unfilled_hp_state = None
    filled_hp_state   = None
    power_state       = None
    coin_state        = None
    coin              = None
    shop              = None

    here_map          = None
    next_map          = None
    here_arrow        = None

    font = None

    def __init__(self):
        self.unfilled_hp_state = load_image('title&menu/main6.png')
        self.filled_hp_state = load_image('title&menu/main6.png')
        self.power_state = load_image('title&menu/main6.png')
        self.coin_state = load_image('title&menu/main6.png')
        self.coin = load_image('title&menu/main6.png')
        self.shop = load_image('title&menu/main6.png')

        self.here_map = load_image('title&menu/main6.png')
        self.next_map = load_image('title&menu/main6.png')
        self.here_arrow = load_image('title&menu/main6.png')

        self.coin1 = random.randint(50, 350)
        self.coin2 = random.randint(50, 350)
        self.coin3 = random.randint(50, 350)

        self.font = load_font('sound&font/my_font.ttf')

    def draw(self):
        self.unfilled_hp_state.clip_draw(130, image_size - 240, 210, 20, 240, 250)
        self.filled_hp_state.clip_draw(130, image_size - 215, 210 - monsters.hp, 20, 240 - monsters.hp / 2, 250)
        self.power_state.clip_draw(455, 0, 485, 190, 240, 80)
        self.coin_state.clip_draw(0, image_size - 550, 340, 60, 240, 775)
        self.coin.clip_draw(342, image_size - 265, 40, 35, 140, 770)
        self.coin.clip_draw(342, image_size - 265, 40, 35, 120, 770)
        self.shop.clip_draw(760, image_size - 835, 210, 60, 160, 80)

        self.here_map.clip_draw(565, image_size - 514, 90, 75, 240, 700)
        self.next_map.clip_draw(940, image_size - 910, 90, 75, 330, 700)
        self.here_arrow.clip_draw(755, image_size - 620, 35, 60, 240, 680)

        if monsters.hp >= 210:
            self.coin.clip_draw(342, image_size - 265, 40, 35, self.coin1, 320)
            self.coin.clip_draw(342, image_size - 265, 40, 35, self.coin2, 320)
            self.coin.clip_draw(342, image_size - 265, 40, 35, self.coin3, 320)

    def show_data(self):
        self.font.draw(240, 766, "%2d" %monsters.coin)
        self.font.draw(20, 130, "upgrade_need_coin : %2d" %monsters.upgrade_coin)
        self.font.draw(350, 90, "damage : %2d" %monsters.damage)
        if monsters.time >= 0:
            self.font.draw(30, 630, "boss time : %2d" %monsters.time)

location = None
monsters = None
menu = None

def create_world():
    global location, monsters, menu
    location = Location()
    monsters = Monsters()
    menu = Menu()

def destroy_world():
    global location, monsters, menu
    del(location)
    del(monsters)
    del(menu)

def enter():
    create_world()

def exit():
    destroy_world()
    close_canvas()

def update():
    monsters.update()

def draw():
    clear_canvas()
    location.draw()
    monsters.draw()
    menu.draw()
    menu.show_data()
    update_canvas()

def handle_events():
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif (event.type, event.button) == (SDL_MOUSEBUTTONDOWN, SDL_BUTTON_LEFT):
            if (60 < event.x and event.x < 265) and (690 < event.y and event.y < 745):
                game_framework.push_state(game_shop)
            if monsters.hp >= 210:
                if (465 < event.y and event.y < 495):
                    if (menu.coin1 - 18 < event.x and event.x < menu.coin1 + 15):
                        monsters.coin += 10
                    if (menu.coin2 - 18 < event.x and event.x < menu.coin2 + 15):
                        monsters.coin += 10
                    if (menu.coin3 - 18 < event.x and event.x < menu.coin3 + 15):
                        monsters.coin += 10
            else:
                monsters.click = true
        elif (event.type, event.button) == (SDL_MOUSEBUTTONUP, SDL_BUTTON_LEFT):
            monsters.click = false
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_a and monsters.coin >= monsters.upgrade_coin:
                monsters.damage += 1
                monsters.coin -= monsters.upgrade_coin
                monsters.upgrade_coin = monsters.upgrade_coin * 2

def pause():
    pass

def resume():
    pass